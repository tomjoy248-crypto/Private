# API 文档

## 接口列表

### 1. 安全扫描

**URL**: `/api/scan`
**Method**: `POST`
**Content-Type**: `application/json`

**请求参数**:

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| url | string | 是 | 目标网站地址 |
| authorized | boolean | 是 | 是否已授权 |

**请求示例**:

```json
{
  "url": "https://example.com",
  "authorized": true
}
```

**响应示例**:

```json
{
  "url": "https://example.com",
  "time": "2026-06-20 11:23:11",
  "score": 68,
  "risk_level": "中风险",
  "scan_mode": "real",
  "ai_report": {
    "summary": "对 example.com 的真实响应头扫描已完成...",
    "priority": "优先修复 HSTS 和 CSP 问题。",
    "boundary": "基于真实 HTTP 响应头分析..."
  },
  "owasp_coverage": [
    {"category": "A01 访问控制失效", "status": "通过", "count": 0, "note": "..."}
  ],
  "findings": [
    {
      "name": "缺少 HSTS 响应头",
      "level": "中风险",
      "owasp": "A05 安全配置错误",
      "summary": "HTTPS 网站未配置 HSTS。",
      "fix": "添加 Strict-Transport-Security 响应头。",
      "ai_advice": "HSTS 强制浏览器使用 HTTPS..."
    }
  ],
  "raw_headers": {
    "content-type": "text/html; charset=UTF-8",
    "server": "ECS (dcb/7EA2)"
  }
}
```

### 2. Nginx 配置修复

**URL**: `/api/fix-config`
**Method**: `POST`

**请求参数**:

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| config | string | 是 | 原始 Nginx 配置 |

**响应示例**:

```json
{
  "issues": [
    {
      "name": "缺少 HSTS",
      "severity": "medium",
      "reason": "防止 HTTPS 降级攻击"
    }
  ],
  "fixed": "server {\n    listen 80;\n    add_header Strict-Transport-Security...\n}",
  "diff": [
    {"type": "context", "line": "server {"},
    {"type": "add", "line": "    add_header Strict-Transport-Security..."}
  ]
}
```

### 3. 根据扫描结果生成修复

**URL**: `/api/generate-fix`
**Method**: `POST`

**请求参数**:

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| findings | array | 是 | 扫描发现的问题列表 |
| config | string | 否 | 原始配置（可选） |

**响应示例**:

```json
{
  "fixes": [
    {"name": "HSTS", "severity": "中风险", "reason": "..."}
  ],
  "fixed_config": "server {\n...\n}",
  "diff": "...",
  "score_after": 80
}
```

## 错误码

| 状态码 | 说明 |
|---|---|
| 200 | 成功 |
| 400 | 参数错误（如未授权） |
| 404 | 接口不存在 |
| 500 | 服务器内部错误 |
| 502 | 目标网站无法访问 |

## 本地测试

```bash
# 启动服务
python3 src/server.py

# 测试扫描
curl -X POST http://localhost:8000/api/scan \
  -H "Content-Type: application/json" \
  -d '{"url":"https://example.com","authorized":true}'

# 测试配置修复
curl -X POST http://localhost:8000/api/fix-config \
  -H "Content-Type: application/json" \
  -d '{"config":"server { listen 80; }"}'
```
