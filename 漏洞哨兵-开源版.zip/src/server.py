#!/usr/bin/env python3
"""漏洞哨兵 V7 - 真实响应头扫描服务"""

import http.client
import ipaddress
import json
import socket
import ssl
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HOST = "127.0.0.1"
PORT = int(__import__("os").environ.get("PORT", "8000"))
MAX_RESPONSE_BYTES = 1024 * 1024
MAX_REDIRECTS = 5
TIMEOUT_SECONDS = 8
_REDIRECT_CODES = {301, 302, 303, 307, 308}


class ScanError(ValueError):
    """A safe, user-displayable scan validation or networking error."""


def _validate_public_host(hostname):
    """Resolve a hostname and reject it unless every answer is globally routable."""
    try:
        records = socket.getaddrinfo(hostname, None, type=socket.SOCK_STREAM)
    except OSError as exc:
        raise ScanError("目标域名无法解析") from exc
    addresses = {record[4][0].split("%", 1)[0] for record in records}
    if not addresses:
        raise ScanError("目标域名没有可用地址")
    for address in addresses:
        try:
            ip = ipaddress.ip_address(address)
        except ValueError as exc:
            raise ScanError("目标域名解析结果无效") from exc
        if (
            ip.is_private
            or ip.is_loopback
            or ip.is_link_local
            or ip.is_reserved
            or ip.is_unspecified
            or ip.is_multicast
        ):
            raise ScanError("目标域名解析到非公网地址，已拒绝扫描")
    return sorted(addresses)


def _validate_url(raw_url):
    """Normalize and validate a single HTTP(S) target before connecting."""
    value = raw_url.strip()
    if not value:
        raise ScanError("请输入目标网址")
    if not value.startswith(("http://", "https://")):
        value = "https://" + value
    if len(value) > 2048 or any(ord(char) < 32 for char in value):
        raise ScanError("目标网址格式无效")
    parsed = urllib.parse.urlsplit(value)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ScanError("仅支持有效的 HTTP 或 HTTPS 网址")
    if parsed.username or parsed.password:
        raise ScanError("目标网址不能包含用户名或密码")
    try:
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
    except ValueError as exc:
        raise ScanError("目标端口无效") from exc
    if not 1 <= port <= 65535:
        raise ScanError("目标端口无效")
    _validate_public_host(parsed.hostname)
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path or "/", parsed.query, ""))


class _PinnedHTTPSConnection(http.client.HTTPSConnection):
    """Connect to a validated IP while retaining hostname-based TLS verification."""

    def __init__(self, hostname, port, address, timeout):
        super().__init__(hostname, port, timeout=timeout, context=ssl.create_default_context())
        self._address = address

    def connect(self):
        self.sock = socket.create_connection((self._address, self.port), self.timeout)
        if self._tunnel_host:
            self._tunnel()
        self.sock = self._context.wrap_socket(self.sock, server_hostname=self.host)


class _PinnedHTTPConnection(http.client.HTTPConnection):
    """Connect to a previously validated address without resolving again."""

    def __init__(self, hostname, port, address, timeout):
        super().__init__(hostname, port, timeout=timeout)
        self._address = address

    def connect(self):
        self.sock = socket.create_connection((self._address, self.port), self.timeout)


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, file_pointer, code, message, headers, new_url):
        return None


def _open_pinned(url):
    """Open a request to one validated public IP, preserving the URL hostname."""
    parsed = urllib.parse.urlsplit(url)
    addresses = _validate_public_host(parsed.hostname)
    address = addresses[0]
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    connection_class = _PinnedHTTPSConnection if parsed.scheme == "https" else _PinnedHTTPConnection
    connection = connection_class(parsed.hostname, port, address, TIMEOUT_SECONDS)
    target = urllib.parse.urlunsplit(("", "", parsed.path or "/", parsed.query, ""))
    connection.request("HEAD", target, headers={
        "User-Agent": "VulnSentinel/7 (authorized security configuration scan)",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Host": parsed.netloc,
        "Connection": "close",
    })
    response = connection.getresponse()
    return connection, response


def real_scan(raw_url):
    """真实响应头扫描。"""
    try:
        url = _validate_url(raw_url)
    except ScanError as exc:
        return {"error": str(exc)}

    final_url = url
    try:
        for redirect_count in range(MAX_REDIRECTS + 1):
            connection, resp = _open_pinned(final_url)
            if resp.status not in _REDIRECT_CODES:
                headers = {k.lower(): v for k, v in resp.getheaders()}
                break
            location = resp.getheader("Location")
            connection.close()
            if not location or redirect_count >= MAX_REDIRECTS:
                return {"error": "目标重定向无效或超过允许次数"}
            try:
                final_url = _validate_url(urllib.parse.urljoin(final_url, location))
            except ScanError as exc:
                return {"error": str(exc)}
        else:
            return {"error": "目标重定向超过允许次数"}
        connection.close()
    except (OSError, ssl.SSLError, http.client.HTTPException, urllib.error.URLError):
        return {"error": "目标无法安全连接，请检查地址、网络和 TLS 证书"}
    
    is_https = final_url.startswith("https://")
    status_code = resp.status
    findings = []
    
    if not is_https:
        findings.append({"name": "未启用 HTTPS", "level": "高风险", "owasp": "A02 加密机制失效",
            "summary": "网站使用 HTTP 明文传输，存在中间人攻击风险。",
            "fix": "配置 SSL 证书并启用 HTTPS 强制跳转。",
            "ai_advice": "所有现代网站都应使用 HTTPS。建议申请 Let's Encrypt 免费证书。"})
    
    if not headers.get("strict-transport-security") and is_https:
        findings.append({"name": "缺少 HSTS 响应头", "level": "中风险", "owasp": "A05 安全配置错误",
            "summary": "HTTPS 网站未配置 HSTS，用户可能通过 HTTP 访问。",
            "fix": "添加 Strict-Transport-Security 响应头。",
            "ai_advice": "HSTS 强制浏览器使用 HTTPS，防止 SSL 剥离攻击。建议配置 max-age=31536000。"})
    
    if not headers.get("content-security-policy"):
        findings.append({"name": "缺少 Content-Security-Policy", "level": "中风险", "owasp": "A03 注入攻击",
            "summary": "未配置内容安全策略，存在 XSS 和数据注入风险。",
            "fix": "配置 CSP 响应头，限制资源加载来源。",
            "ai_advice": "CSP 是防御 XSS 的关键手段。建议从 default-src 'self' 开始，逐步细化。"})
    
    if not headers.get("x-frame-options"):
        findings.append({"name": "缺少 X-Frame-Options", "level": "低风险", "owasp": "A05 安全配置错误",
            "summary": "未配置点击劫持防护，页面可能被嵌入恶意 iframe。",
            "fix": "添加 X-Frame-Options: DENY 或 SAMEORIGIN。",
            "ai_advice": "点击劫持攻击可诱导用户点击隐藏按钮。X-Frame-Options 是最简单的防护。"})
    
    if not headers.get("x-content-type-options"):
        findings.append({"name": "缺少 X-Content-Type-Options", "level": "低风险", "owasp": "A05 安全配置错误",
            "summary": "浏览器可能通过 MIME 嗅探执行恶意文件。",
            "fix": "添加 X-Content-Type-Options: nosniff。",
            "ai_advice": "nosniff 防止浏览器将无害文件类型解释为可执行脚本。"})
    
    if not headers.get("referrer-policy"):
        findings.append({"name": "缺少 Referrer-Policy", "level": "低风险", "owasp": "A05 安全配置错误",
            "summary": "Referer 信息可能泄露用户隐私和内部 URL 结构。",
            "fix": "添加 Referrer-Policy: strict-origin-when-cross-origin。",
            "ai_advice": "控制 Referer 泄露范围，保护用户隐私和内部 URL 结构。"})
    
    server = headers.get("server", "")
    if server and len(server) > 3 and not any(x in server.lower() for x in ["cloudflare", "fastly", "akamai"]):
        findings.append({"name": "服务器信息暴露", "level": "低风险", "owasp": "A05 安全配置错误",
            "summary": f"Server 头暴露具体版本信息: {server}",
            "fix": "隐藏 Server 响应头。",
            "ai_advice": "暴露服务器版本会降低攻击者侦察成本。建议隐藏或使用通用名称。"})
    
    acao = headers.get("access-control-allow-origin", "")
    if acao == "*":
        findings.append({"name": "CORS 允许任意来源", "level": "中风险", "owasp": "A01 访问控制失效",
            "summary": "CORS 配置为 *，允许任意网站跨域访问。",
            "fix": "限制为特定域名。",
            "ai_advice": "通配符 CORS 配置可能导致敏感数据泄露。建议白名单化。"})
    
    score = 100
    for f in findings:
        if f["level"] == "高风险": score -= 18
        elif f["level"] == "中风险": score -= 10
        elif f["level"] == "低风险": score -= 4
    score = max(10, min(98, score))
    risk_level = "低风险" if score >= 80 else "中风险" if score >= 60 else "高风险"
    
    return {
        "url": final_url,
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "score": score,
        "risk_level": risk_level,
        "scan_mode": "real",
        "scope": "响应头和 TLS 基线；不代表完成渗透测试或业务授权测试",
        "evidence": {"status_code": status_code, "final_url": final_url},
        "ai_report": {
            "summary": f"真实响应头扫描完成。发现 {len(findings)} 个问题，评分 {score} 分。",
            "priority": "优先修复 HSTS 和 CSP 问题。",
            "boundary": "基于真实 HTTP 响应头分析，不涉及渗透测试。",
        },
        "owasp_coverage": [
            {"category": "A01 访问控制失效", "status": "未覆盖", "count": 0, "note": "需要认证态和对象级授权测试"},
            {"category": "A02 加密机制失效", "status": "通过" if is_https else "高风险", "count": 0, "note": "基于响应头分析"},
            {"category": "A03 注入攻击", "status": "通过" if headers.get("content-security-policy") else "中风险", "count": 0, "note": "基于响应头分析"},
            {"category": "A04 不安全设计", "status": "未覆盖", "count": 0, "note": "需要业务流程和威胁建模测试"},
            {"category": "A05 安全配置错误", "status": "通过" if len([f for f in findings if "A05" in f["owasp"]]) < 2 else "中风险", "count": 0, "note": "基于响应头分析"},
            {"category": "A06 过时组件", "status": "未覆盖", "count": 0, "note": "需要依赖和版本识别"},
            {"category": "A07 认证失败", "status": "未覆盖", "count": 0, "note": "需要登录、会话和 MFA 测试"},
            {"category": "A08 软件完整性", "status": "未覆盖", "count": 0, "note": "需要构建链和依赖完整性测试"},
            {"category": "A09 日志监控不足", "status": "未覆盖", "count": 0, "note": "需要日志和监控配置审查"},
            {"category": "A10 服务端请求伪造", "status": "未覆盖", "count": 0, "note": "本扫描器不测试应用层 SSRF"},
        ],
        "findings": findings,
        "raw_headers": dict(headers),
    }


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def _send_json(self, data, code=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, html, code=200):
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(html.encode("utf-8"))

    def do_GET(self):
        if self.path == "/" or self.path == "/index.html":
            html = Path(__file__).with_name("index.html").read_text(encoding="utf-8")
            self._send_html(html)
            return
        self.send_error(404)

    def do_POST(self):
        if self.path == "/api/scan":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > 16 * 1024:
                    self._send_json({"error": "请求体大小无效"}, 400)
                    return
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(payload, dict) or not isinstance(payload.get("url"), str):
                    self._send_json({"error": "请求参数无效"}, 400)
                    return
                url = payload["url"]
                authorized = payload.get("authorized", False)
                if not authorized:
                    self._send_json({"error": "请先确认授权"}, 400)
                    return
                result = real_scan(url)
                if "error" in result:
                    self._send_json({"error": result["error"]}, 400)
                    return
                self._send_json(result)
            except (UnicodeDecodeError, json.JSONDecodeError):
                self._send_json({"error": "请求 JSON 无效"}, 400)
            except (BrokenPipeError, ConnectionResetError):
                return
            except Exception:
                self._send_json({"error": "服务器处理请求失败"}, 500)
            return
        self.send_error(404)


if __name__ == "__main__":
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"漏洞哨兵 V7 已启动：http://localhost:{PORT}")
    print("按 Ctrl+C 停止服务")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n服务已停止")
