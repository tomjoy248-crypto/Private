# 漏洞哨兵 (Vuln Sentinel)

> AI 驱动的 Web 安全扫描与配置修复平台，守护您的网站安全。

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/)
[![Version](https://img.shields.io/badge/version-V7-green.svg)]()

## 功能特性

- **真实响应头扫描**：基于真实 HTTP 请求，读取目标网站响应头，检测安全配置
- **AI 安全报告**：自动生成安全评分、风险等级、修复建议
- **域名归属验证**：DNS TXT / 网站文件验证，确保合规扫描
- **配置修复器**：Nginx 配置自动分析，生成安全补丁和 Diff
- **GitHub PR 修复**：模拟修复流程，展示代码变更
- **规则化评分**：基础 100 分，按风险等级扣减，修复后加分
- **OWASP Top 10 覆盖**：可视化展示安全检测覆盖情况
- **移动端友好**：完整的 Web App 体验，支持底部导航

## 安全检测项

| 检测项 | 风险等级 | 说明 |
|---|---|---|
| HTTPS 未启用 | 高风险 | 通信明文传输，存在中间人攻击风险 |
| 缺少 HSTS | 中风险 | 防止 SSL 剥离攻击 |
| 缺少 CSP | 中风险 | 防御 XSS 和数据注入 |
| 缺少 X-Frame-Options | 低风险 | 防止点击劫持 |
| 缺少 X-Content-Type-Options | 低风险 | 防止 MIME 嗅探攻击 |
| 缺少 Referrer-Policy | 低风险 | 保护隐私和 URL 结构 |
| 服务器信息暴露 | 低风险 | 降低攻击者侦察成本 |
| CORS 允许任意来源 | 中风险 | 可能导致敏感数据泄露 |

## 快速开始

### 方式一：离线体验（前端演示）

```bash
# 下载后解压，双击打开 index.html
# 体验完整的 UI 流程（扫描结果为模拟数据）
```

### 方式二：真实扫描（推荐）

```bash
# 1. 克隆仓库
git clone https://github.com/yourname/vuln-sentinel.git
cd vuln-sentinel

# 2. 启动服务（默认仅监听本机 127.0.0.1）
python3 src/server.py

# 3. 浏览器访问 http://localhost:8000
# 输入已获授权的目标网站，获取真实安全扫描结果
```

## 项目结构

```
vuln-sentinel/
├── src/
│   ├── server.py          # 主服务（HTTP 服务器 + 真实扫描 API）
│   ├── scan_engine.py     # 扫描引擎（响应头分析）
│   ├── fix_engine.py      # 修复引擎（Nginx 配置修复）
│   └── static/
│       └── index.html     # 前端页面
├── docs/
│   ├── ARCHITECTURE.md    # 架构设计文档
│   └── API.md             # API 接口文档
├── assets/
│   └── screenshots/       # 项目截图
├── LICENSE                # MIT 许可证
└── README.md              # 本文件
```

## 技术栈

- **前端**：纯 HTML/CSS/JavaScript，无框架依赖
- **后端**：Python 3.8+，标准库 HTTP 服务器
- **扫描引擎**：固定到已验证公网 IP 的 HTTP(S) 请求，默认校验证书并重新校验重定向
- **安全标准**：OWASP Top 10 2021

## 评分规则

```
基础分：100
高风险问题：-18
中风险问题：-10
低风险问题：-4
已生成修复配置：+12
已完成 PR 修复：+10
最高分：98
```

## 合规声明

**本工具仅供安全研究和授权测试使用。**

- 扫描前需完成域名归属验证
- 每次扫描需确认授权声明
- 未经授权扫描他人网站属于违法行为
- 开发者不对滥用行为承担任何责任

## 商业模式

```
免费层：安全扫描 + AI 报告 + 修复建议
付费层：自动修复配置 + GitHub PR + 持续监控
```

## 贡献指南

欢迎提交 Issue 和 Pull Request！

1. Fork 本仓库
2. 创建特性分支：`git checkout -b feature/xxx`
3. 提交更改：`git commit -am 'Add xxx'`
4. 推送分支：`git push origin feature/xxx`
5. 创建 Pull Request

## 路线图

- [x] V1-V6：前端演示版本
- [x] V7：真实响应头扫描
- [ ] V8：依赖组件扫描（检测过时库）
- [ ] V9：漏洞数据库集成（CVE 匹配）
- [ ] V10：SaaS 化部署

## 许可证

[MIT](LICENSE) © 2026 漏洞哨兵
