# 贡献指南

感谢你对漏洞哨兵的兴趣！以下是参与贡献的方式。

## 如何贡献

### 报告 Bug

1. 先搜索已有 Issue，避免重复
2. 创建新 Issue，包含：
   - 问题描述
   - 复现步骤
   - 期望结果 vs 实际结果
   - 环境信息（操作系统、浏览器、Python 版本）

### 提交代码

1. Fork 本仓库
2. 创建分支：`git checkout -b feature/你的特性名`
3. 编写代码，保持风格一致
4. 提交 PR，描述清楚改动内容

## 代码规范

- Python：PEP 8
- JavaScript：ES6+
- HTML/CSS：语义化标签，CSS 变量管理主题色
- 注释：中文注释，关键逻辑说明清楚

## 开发环境

```bash
# 克隆仓库
git clone https://github.com/yourname/vuln-sentinel.git
cd vuln-sentinel

# 启动开发服务器
python3 src/server.py

# 浏览器访问 http://localhost:8000
```

## 联系方式

- Issue：[GitHub Issues](https://github.com/yourname/vuln-sentinel/issues)
- 邮箱：your-email@example.com
